# include <iostream>
using namespace std;
int main()
{
	int a,b,t;
	char c;
	cout<<"enter the first no:";
	cin>>a;
	cout<<"enter the second no:";
	cin>>b;
	cout<<"enter the arithmatic operater(+,-,*,/,%):";
	cin>>c;
	
	switch(c)
		{
			case '+':
				t=a+b;
				break;
		    case '-':
		    	t=a-b;
		    	break;
		    case '*':
		    	t=a*b;
		    	break;
		    case '/':
		    	t=a/b;
		    	break;
		    case '%':
		    	t=a%b;
		    	break;
		    default:
		    	cout<<"invalid operater";
		}
	
	cout<<"TOTAL="<<t;
	
}
