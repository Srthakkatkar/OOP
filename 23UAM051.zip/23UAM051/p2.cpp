# include <iostream>
using namespace std;
int main()
{
  int a,b,c;
  cout<<"enter the three no (A,B,C):";
  cin>>a>>b>>c;
  if(a>b&&a>c)
  {
  	cout<<"A is greater.";
  }
  else if(b>a&&b>c)
  {
  	cout<<"B is greater";
  }
  else
  {
  	cout<<"c is greater";
  }
}
